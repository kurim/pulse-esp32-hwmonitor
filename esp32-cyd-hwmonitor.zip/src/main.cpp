#include <Arduino.h>
#include "shared_state.h"
#include "config_store.h"
#include "display_ui.h"
#include "web_portal.h"
#include "mqtt_handler.h"
#include "weather_service.h"
#include "time_service.h"

// Globale Zustände (siehe shared_state.h)
AppConfig appConfig;
HWInfo hwInfo;
WeatherInfo weatherInfo;
History cpuHistory;
History gpuHistory;
bool wifiConnected = false;
bool mqttConnected = false;

void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println("\n=== CYD Hardware-Monitor ===");

  ConfigStore::begin();
  ConfigStore::load(appConfig);

  // Display zuerst, damit beim Boot Status sichtbar ist (z.B. AP-SSID/IP)
  DisplayUI::begin();

  WebPortal::begin();      // verbindet WLAN bzw. startet Config-AP + Webserver
  TimeService::begin();    // NTP + Zeitzone
  MqttHandler::begin();    // MQTT-Verbindung zu Hardwaredaten
  WeatherService::begin(); // optionaler erster Wetter-Abruf

  Serial.println("Setup abgeschlossen.");
}

void loop() {
  WebPortal::loop();
  MqttHandler::loop();
  WeatherService::loop();
  DisplayUI::loop();
}
